package com.mukesh.ipcameraviewer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class CameraStore(context: Context) {
    private val prefs = context.getSharedPreferences("cameras", Context.MODE_PRIVATE)

    fun load(): MutableList<Camera> {
        val result = mutableListOf<Camera>()
        val raw = prefs.getString("items", "[]") ?: "[]"
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            result += Camera(o.getLong("id"), o.optString("name"), o.optString("rtsp"), o.optString("onvif"), o.optString("user"), o.optString("pass"))
        }
        return result
    }

    fun save(items: List<Camera>) {
        val arr = JSONArray()
        items.forEach { c ->
            arr.put(JSONObject().apply {
                put("id", c.id); put("name", c.name); put("rtsp", c.rtspUrl)
                put("onvif", c.onvifUrl); put("user", c.username); put("pass", c.password)
            })
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
