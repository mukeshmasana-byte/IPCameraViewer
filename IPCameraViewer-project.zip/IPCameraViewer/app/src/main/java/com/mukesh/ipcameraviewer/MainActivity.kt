package com.mukesh.ipcameraviewer

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private lateinit var store: CameraStore
    private val cameras = mutableListOf<Camera>()
    private val players = mutableMapOf<Long, ExoPlayer>()
    private lateinit var grid: GridLayout
    private var columns = 2
    private var fullScreenId: Long? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = CameraStore(this)
        cameras += store.load()
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(18,18,18)) }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(10,6,10,6); setBackgroundColor(Color.rgb(32,32,32)) }
        val title = TextView(this).apply { text = "IP CAMERA VIEWER"; textSize = 16f; setTextColor(Color.WHITE); setTypeface(typeface, 1) }
        bar.addView(title, LinearLayout.LayoutParams(0, 48, 1f))
        bar.addView(button("1×1") { setGrid(1) })
        bar.addView(button("2×2") { setGrid(2) })
        bar.addView(button("3×3") { setGrid(3) })
        bar.addView(button("＋ Camera") { cameraDialog(null) })
        bar.addView(button("ONVIF") { discoverOnvif() })
        root.addView(bar)
        grid = GridLayout(this).apply { setBackgroundColor(Color.BLACK); alignmentMode = GridLayout.ALIGN_BOUNDS; useDefaultMargins = false }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        setGrid(columns)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 11f; isAllCaps = false; setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(72, 44).apply { setMargins(3,0,3,0) }
    }

    private fun setGrid(cols: Int) {
        columns = cols
        fullScreenId = null
        releasePlayers()
        grid.removeAllViews()
        grid.columnCount = cols
        grid.rowCount = max(1, (cameras.size.coerceAtMost(cols * cols) + cols - 1) / cols)
        val count = cols * cols
        for (i in 0 until count) {
            val camera = cameras.getOrNull(i)
            val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
            val lp = GridLayout.LayoutParams().apply { width = 0; height = 0; columnSpec = GridLayout.spec(i % cols, 1, 1f); rowSpec = GridLayout.spec(i / cols, 1, 1f) }
            grid.addView(frame, lp)
            if (camera != null) attachCamera(frame, camera)
            else addEmpty(frame, i + 1)
        }
    }

    private fun addEmpty(frame: FrameLayout, slot: Int) {
        val t = TextView(this).apply { text = "Camera $slot\nTap ＋ Camera to add"; gravity = Gravity.CENTER; setTextColor(Color.GRAY); textSize = 14f }
        frame.addView(t, FrameLayout.LayoutParams(-1,-1))
    }

    private fun attachCamera(frame: FrameLayout, camera: Camera) {
        val pv = PlayerView(this).apply { useController = false; setShutterBackgroundColor(Color.BLACK) }
        frame.addView(pv, FrameLayout.LayoutParams(-1,-1))
        val label = TextView(this).apply { text = camera.name; setTextColor(Color.WHITE); setBackgroundColor(0x99000000.toInt()); setPadding(8,4,8,4) }
        frame.addView(label, FrameLayout.LayoutParams(-2,-2).apply { gravity = Gravity.TOP or Gravity.START })
        frame.setOnClickListener { cameraDialog(camera) }
        if (camera.rtspUrl.isBlank()) return
        val uri = buildUri(camera)
        val player = ExoPlayer.Builder(this).build()
        val source = RtspMediaSource.Factory().setForceUseRtpTcp(true).createMediaSource(MediaItem.fromUri(uri))
        player.setMediaSource(source)
        player.volume = if (columns == 1) 1f else 0f
        player.playWhenReady = true
        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onPlayerError(error: PlaybackException) { label.text = "${camera.name}  •  STREAM ERROR" }
        })
        player.prepare()
        pv.player = player
        players[camera.id] = player
    }

    private fun buildUri(c: Camera): String {
        if (c.username.isBlank()) return c.rtspUrl
        return try {
            val uri = android.net.Uri.parse(c.rtspUrl)
            val host = uri.host ?: return c.rtspUrl
            val port = if (uri.port > 0) ":${uri.port}" else ""
            val path = uri.encodedPath ?: ""
            val query = if (uri.encodedQuery != null) "?${uri.encodedQuery}" else ""
            "rtsp://${android.net.Uri.encode(c.username)}:${android.net.Uri.encode(c.password)}@$host$port$path$query"
        } catch (_: Exception) { c.rtspUrl }
    }

    private fun releasePlayers() { players.values.forEach { it.release() }; players.clear() }

    private fun cameraDialog(existing: Camera?) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40,10,40,0) }
        fun field(hint: String, value: String = "") = EditText(this).apply { this.hint = hint; setText(value); singleLine = true }
        val name = field("Camera name", existing?.name ?: "Camera ${cameras.size + 1}")
        val rtsp = field("RTSP URL", existing?.rtspUrl ?: "rtsp://192.168.1.100:554/stream")
        val user = field("Username (optional)", existing?.username ?: "")
        val pass = field("Password (optional)", existing?.password ?: "").apply { inputType = 0x81 }
        val onvif = field("ONVIF XAddr (optional)", existing?.onvifUrl ?: "")
        listOf(name,rtsp,user,pass,onvif).forEach { box.addView(it, LinearLayout.LayoutParams(-1,54)) }
        val dialog = AlertDialog.Builder(this).setTitle(if (existing == null) "Add Camera" else "Edit Camera").setView(box)
            .setPositiveButton("Save", null).setNegativeButton("Cancel", null)
        if (existing != null) dialog.setNeutralButton("Delete") { _, _ -> cameras.removeAll { it.id == existing.id }; store.save(cameras); setGrid(columns) }
        val d = dialog.create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = name.text.toString().trim(); val u = rtsp.text.toString().trim()
                if (n.isBlank() || u.isBlank()) { Toast.makeText(this,"Name and RTSP URL are required",Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                if (existing == null) cameras += Camera(System.currentTimeMillis(),n,u,onvif.text.toString().trim(),user.text.toString(),pass.text.toString())
                else { existing.name=n; existing.rtspUrl=u; existing.onvifUrl=onvif.text.toString().trim(); existing.username=user.text.toString(); existing.password=pass.text.toString() }
                store.save(cameras); d.dismiss(); setGrid(columns)
            }
        }
        d.show()
    }

    private fun discoverOnvif() {
        Toast.makeText(this,"Searching local network for ONVIF cameras…",Toast.LENGTH_SHORT).show()
        lifecycleScope.launch(Dispatchers.IO) {
            val devices = try { OnvifDiscovery.discover() } catch (_: Exception) { emptyList() }
            withContext(Dispatchers.Main) {
                if (devices.isEmpty()) { Toast.makeText(this@MainActivity,"No ONVIF devices found",Toast.LENGTH_LONG).show(); return@withContext }
                val labels = devices.map { "${it.address}\n${it.xAddrs.ifBlank { "ONVIF device" }}" }.toTypedArray()
                AlertDialog.Builder(this@MainActivity).setTitle("ONVIF devices found").setItems(labels) { _, which ->
                    val x = devices[which]
                    cameraDialog(Camera(System.currentTimeMillis(), x.address, "", x.xAddrs))
                }.setNegativeButton("Close", null).show()
            }
        }
    }

    override fun onDestroy() { releasePlayers(); super.onDestroy() }
}
